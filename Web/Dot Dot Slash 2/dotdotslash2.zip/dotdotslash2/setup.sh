#!/bin/sh

echo $FLAG > flag.txt
python3 main.py